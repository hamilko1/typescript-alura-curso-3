export interface Comparavel<T> {
    ehIgual(objeto: T): boolean;
}