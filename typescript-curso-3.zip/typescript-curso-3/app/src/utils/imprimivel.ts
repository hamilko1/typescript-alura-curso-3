export interface Imprimivel {
    paraTexto(): string;
}